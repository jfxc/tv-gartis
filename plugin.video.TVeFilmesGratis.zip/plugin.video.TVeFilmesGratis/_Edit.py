import xbmcaddon

MainBase = 'https://pastebin.com/raw/D08ewyr5'
addon = xbmcaddon.Addon('plugin.video.TVeFilmesGratis')